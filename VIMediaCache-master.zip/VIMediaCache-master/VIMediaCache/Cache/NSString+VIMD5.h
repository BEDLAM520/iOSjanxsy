//
//  NSString+VIMD5.h
//  VIMediaCacheDemo
//
//  Created by Vito on 21/11/2017.
//  Copyright © 2017 Vito. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (VIMD5)
- (NSString *)vi_md5;
@end
